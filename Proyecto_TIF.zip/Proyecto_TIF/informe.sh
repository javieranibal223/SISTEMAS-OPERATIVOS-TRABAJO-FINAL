#!/bin/bash
# Script que genera un informe con CPU, memoria y disco

USERNAME="${USERNAME:-$USER}"

YELLOW="\033[33m"
GREEN="\033[32m"
RESET="\033[0m"

echo -e "${YELLOW}🔹 Generando informe del sistema...${RESET}"

LOG_FILE="/c/Users/$USERNAME/Desktop/informe_sistema.log"

{
    echo "=============================="
    echo "📅 Fecha: $(date)"
    echo "=============================="
    echo "🔸 CPU:"
    top -bn1 2>/dev/null | head -n 6 || echo "top no disponible"
    echo "------------------------------"
    echo "🔸 Memoria:"
    free -h 2>/dev/null || echo "free no disponible"
    echo "------------------------------"
    echo "🔸 Disco:"
    df -h 2>/dev/null || echo "df no disponible"
    echo
} >> "$LOG_FILE"

echo -e "${GREEN}✅ Informe guardado en: $LOG_FILE${RESET}"
echo

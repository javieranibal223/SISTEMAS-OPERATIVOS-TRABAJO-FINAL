#!/bin/bash
# Script de respaldo de directorio y limpieza de backups antiguos

USERNAME="${USERNAME:-$USER}"

YELLOW="\033[33m"
GREEN="\033[32m"
RED="\033[31m"
BLUE="\033[34m"
RESET="\033[0m"

echo -e "${YELLOW}🔹 Iniciando respaldo del directorio...${RESET}"

# Directorio de origen y destino
ORIGEN="/c/Users/$USERNAME/Documents"
BACKUP_DIR="/c/Users/$USERNAME/Desktop/backups"

# Fecha actual
FECHA=$(date +%Y%m%d_%H%M)
ARCHIVO="backup_${FECHA}.tar.gz"

# Crear carpeta de backup si no existe
mkdir -p "$BACKUP_DIR"

# Crear archivo comprimido
if tar -czf "$BACKUP_DIR/$ARCHIVO" "$ORIGEN" 2>/dev/null; then
    echo -e "${GREEN}✅ Backup creado: $BACKUP_DIR/$ARCHIVO${RESET}"
else
    echo -e "${RED}❌ Error creando backup. Verifique rutas y permisos.${RESET}"
fi

# Eliminar backups de más de 7 días
find "$BACKUP_DIR" -name "backup_*.tar.gz" -mtime +7 -exec rm -f {} \; 2>/dev/null
echo -e "${BLUE}🧹 Backups antiguos eliminados (si existían).${RESET}"
echo

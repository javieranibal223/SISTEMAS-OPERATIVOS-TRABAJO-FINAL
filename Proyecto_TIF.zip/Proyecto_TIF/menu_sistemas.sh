#!/bin/bash
# ============================
# MENÚ PRINCIPAL DEL PROYECTO
# ============================

USERNAME="${USERNAME:-$USER}"  # Detecta tu usuario Windows

# Colores
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[34m"
RESET="\033[0m"

while true; do
    echo -e "${BLUE}=============================="
    echo "     🧩 MENU PRINCIPAL"
    echo "==============================${RESET}"
    echo "1) Realizar respaldo de directorio"
    echo "2) Generar informe del sistema"
    echo "3) Eliminar archivos temporales"
    echo "4) Salir"
    echo -n -e "${YELLOW}Seleccione una opción [1-4]: ${RESET}"
    read opcion

    # Validación de entrada
    if ! [[ "$opcion" =~ ^[1-4]$ ]]; then
        echo -e "${RED}❌ Opción inválida. Ingrese un número del 1 al 4.${RESET}"
        echo
        continue
    fi

    case $opcion in
        1) bash backup.sh ;;
        2) bash informe.sh ;;
        3) bash limpieza.sh ;;
        4)
            echo -e "${GREEN}👋 Saliendo del programa...${RESET}"
            break
            ;;
    esac
done

#!/bin/bash
# Script que elimina archivos temporales de Windows

USERNAME="${USERNAME:-$USER}"

YELLOW="\033[33m"
GREEN="\033[32m"
RED="\033[31m"
RESET="\033[0m"

echo -e "${YELLOW}🔹 Eliminando archivos temporales...${RESET}"

TEMP_DIRS=(
    "/c/Windows/Temp"
    "/c/Users/$USERNAME/AppData/Local/Temp"
)

for dir in "${TEMP_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        rm -rf "$dir"/* 2>/dev/null || echo -e "${RED}❌ Algunos archivos no pudieron eliminarse.${RESET}"
        echo -e "${GREEN}🧹 Limpieza completada en: $dir${RESET}"
    else
        echo -e "${RED}⚠️ Carpeta no encontrada: $dir${RESET}"
    fi
done
echo
